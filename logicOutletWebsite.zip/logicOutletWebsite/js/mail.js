$(function(){
  if($('#contactForm').length > 0){
   
        var $name = $('#name_txt');
        var $email = $('#email_txt');
        var $message = $('#message_txt');
       
        var $error = $('#contactError');
        var $success = $('#contactSuccess');

        $('#send_mail').click(function(e){
            e.preventDefault();

            var ok = true;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

            if($name.val().length < 3){
                showError($name);
                ok = false;
            }

            if($email.val() == ''  || !emailReg.test($email.val())){
                showError($email);
                ok = false;
            }
	    
	    if($message.val() < 10){
	    	showError($message);
	    	ok = false;
	    } 	

            function showError($input){              
                $input.addClass('contactErrorBorder');
                $error.fadeIn();
            }

            function isNumber(n) {
                return !isNaN(parseFloat(n)) && isFinite(n);
            }

            if(ok){
              
                var data = $("#contactForm").serialize();
                console.log(data);
                $.ajax({
                    type: 'POST',
                    url: 'http://sysweave.com/js/sendmail.php',
                    data: data,
                    success: function(msg){
                        console.log(msg);
                        if(msg === '1'){
                            $success.addClass('contactErrorBorder');
                            $success.text('Some error ocurred.');
                            $success.fadeIn();

                            setTimeout(function(){
                                $success.removeClass('contactErrorBorder').fadeOut().css('display','none');
                                $success.text('Successfully submitted.');
                            },4000)
                        }else if(msg === '0'){
                            $success.fadeIn();
                            setTimeout(function(){
                                $success.fadeOut();
                            },4000);
                        }

                    }
                },'html');

            }

            return false;

        });

        $name.focus(function(){resetError($(this))});
        $email.focus(function(){resetError($(this))});
        $message.focus(function(){resetError($(this))});

        function resetError($input){
            $input.removeClass('contactErrorBorder');
            $error.fadeOut();
        }

    }
});